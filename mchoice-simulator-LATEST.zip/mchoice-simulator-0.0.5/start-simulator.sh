#!/bin/sh


java -jar mchoice-simulator.jar
