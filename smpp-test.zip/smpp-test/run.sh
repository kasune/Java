rm src/*.class

javac -cp lib/log4j-1.2.15.jar:lib/smppapi-1.0.jar src/*.java

cd src
pwd

java -cp lib/log4j-1.2.15.jar:lib/smppapi-1.0.jar:./src/ SampleClient