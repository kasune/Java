/* 
 *   (C) Copyright 2006-2007 hSenid Software International (Pvt) Limited. 
 *   All Rights Reserved. 
 * 
 *   These materials are unpublished, proprietary, confidential source code of 
 *   hSenid Software International (Pvt) Limited and constitute a TRADE SECRET 
 *   of hSenid Software International (Pvt) Limited. 
 * 
 *   hSenid Software International (Pvt) Limited retains all title to and intellectual 
 *   property rights in these materials. 
 *
 */

import ie.omk.smpp.Address;
import ie.omk.smpp.Connection;
import ie.omk.smpp.event.ConnectionObserver;
import ie.omk.smpp.event.SMPPEvent;
import ie.omk.smpp.message.BindResp;
import ie.omk.smpp.message.SMPPPacket;
import ie.omk.smpp.message.SubmitMulti;
import ie.omk.smpp.message.SubmitSM;
import ie.omk.smpp.message.tlv.TLVTable;
import ie.omk.smpp.message.tlv.Tag;
import ie.omk.smpp.version.SMPPVersion;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * $LastChangedDate$
 * $LastChangedBy$
 * $LastChangedRevision$
 */
public class SampleClient implements ConnectionObserver{


    Connection smscConnection;
    String host = "127.0.0.1";
    int port = 3001;
    String systemId = "1";
    String password = "1";
    int addressTon = 2;
    int addressNpi = 0;
    String addressRange = "*";
    String systemType = "ESME";
    int bindStatus;
    boolean isBound;
    private final Object respLock = new Object();



    private void connect(ConnectionObserver connectionObserver) throws IOException, InterruptedException {
        smscConnection = new Connection(host, port , true);
        smscConnection.addObserver(connectionObserver);
        smscConnection.autoAckLink(true);
        smscConnection.autoAckMessages(true);
        smscConnection.setVersion(SMPPVersion.V34);
        smscConnection.getState();
        BindResp bindResp = smscConnection.bind(Connection.TRANSCEIVER, systemId, password, systemType, addressTon, addressNpi, addressRange);
        Thread.sleep(3000);
    }

    public void packetReceived(Connection connection, SMPPPacket packet) {

        switch (packet.getCommandId()) {
            // A connected ESME has requested to bind as an ESME Transceiver
            //(by issuing a bind_transceiver PDU) and has received a response from
            // the SMSC authorising its Bind request. An ESME bound as a Transceiver
            // supports the complete set of operations supported by a Transmitter
            // ESME and a Receiver ESME. Thus an ESME bound as a transceiver may
            // send short messages to an SMSC for onward delivery to a Mobile Station
            // or to another ESME. The ESME may also receive short messages from an
            // SMSC which may be originated by a mobile station, by another ESME or
            // by the SMSC itself (for example an SMSC delivery receipt).
            case SMPPPacket.BIND_TRANSCEIVER_RESP:
                System.out.println("BIND_TRANSCEIVER_RESP");
                bindStatus = packet.getCommandStatus();
                System.out.println("bindStatus = " + bindStatus);
                isBound = true;
                break;

                // An ESME has unbound from the SMSC and has closed the network
                // connection. The SMSC may also unbind from the ESME.
            case SMPPPacket.UNBIND_RESP: {
                System.out.println(" unbound successfuly");
                break;
            }
            // This message can be sent by either the ESME or SMSC and is used
            // to provide a confidence-check of the communication path between
            // an ESME and an SMSC. On receipt of this request the receiving
            // party should respond with an enquire_link_resp, thus verifying
            // that the application level connection between the SMSC and the
            // ESME is functioning. The ESME may also respond by sending any
            // valid SMPP primitive.
            case SMPPPacket.ENQUIRE_LINK:
                System.out.println("ENQUIRE_LINK packet received");
                break;

            case SMPPPacket.ENQUIRE_LINK_RESP:
                System.out.println("ENQUIRE_LINK_RESP packet received");
                break;

            case SMPPPacket.DELIVER_SM: {
                System.out.println("net.java.slee.resource.smpp.DELIVER_SM");
                break;
            }
            // The command acknowledges deliver_sm message.
            case SMPPPacket.DELIVER_SM_RESP: {
                System.out.println("net.java.slee.resource.smpp.DELIVER_SM_RESP");
                break;
            }

            case SMPPPacket.DATA_SM: {
                System.out.println("net.java.slee.resource.smpp.DATA_SM");
                break;
            }
            case SMPPPacket.DATA_SM_RESP: {
                System.out.println("net.java.slee.resource.smpp.DATA_SM_RESP");
                break;
            }

            case SMPPPacket.SUBMIT_SM: {
                System.out.println("net.java.slee.resource.smpp.SUBMIT_SM");
                break;
            }

            case SMPPPacket.SUBMIT_SM_RESP: {
                System.out.println("net.java.slee.resource.smpp.SUBMIT_SM_RESP");
                System.out.println("packet.getEsmClass() = " + packet.getEsmClass());
                System.out.println("packet.getMessageStatus() = " + packet.getMessageStatus());
                System.out.println("packet.getErrorCode() = " + packet.getErrorCode());
                System.out.println("packet.getDataCoding() = " + packet.getDataCoding());
                System.out.println("packet.getCommandStatus() = " + packet.getCommandStatus());
                try {
                    Thread.sleep(5);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                synchronized (respLock) {
                    respLock.notify();
                }
                System.out.println("mark the as resp received");
                break;
            }


            case SMPPPacket.SUBMIT_MULTI_RESP: {
                System.out.println("net.java.slee.resource.smpp.SUBMIT_SM_RESP");
                System.out.println("packet.getEsmClass() = " + packet.getEsmClass());
                System.out.println("packet.getMessageStatus() = " + packet.getMessageStatus());
                System.out.println("packet.getErrorCode() = " + packet.getErrorCode());
                System.out.println("packet.getDataCoding() = " + packet.getDataCoding());
                System.out.println("packet.getCommandStatus() = " + packet.getCommandStatus());
                System.out.println("packet.getMessageText() = " + packet.getMessageText());
                System.out.println("packet.getMessageId() = " + packet.getMessageId());
                System.out.println(new String((byte[]) packet.getTLVTable().get(Tag.MESSAGE_PAYLOAD)));
                try {

                    Thread.sleep(5);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                synchronized (respLock) {
                    respLock.notify();
                }
                System.out.println("mark the as resp received");
                break;
            }




            case SMPPPacket.QUERY_SM: {
                System.out.println("net.java.slee.resource.smpp.QUERY_SM");
                break;
            }

            case SMPPPacket.QUERY_SM_RESP: {
                System.out.println("net.java.slee.resource.smpp.QUERY_SM_RESP");
                break;
            }

            case SMPPPacket.REPLACE_SM: {
                System.out.println("net.java.slee.resource.smpp.REPLACE_SM");
                break;
            }

            case SMPPPacket.REPLACE_SM_RESP: {
                System.out.println("net.java.slee.resource.smpp.REPLACE_SM_RESP");
                break;
            }
            default:
                System.out.println("Unexpected packet received! Id = 0x" +
                        Integer.toHexString(packet.getCommandId()));
        }
    }

    public void update(Connection connection, SMPPEvent event) {
        System.out.println("update method called");
    }

    public void submitMessage(SubmitSM submitSM) throws IOException, InterruptedException {
        if (isBound) {
            System.out.println("send message");
            smscConnection.sendRequest(submitSM);
            synchronized (respLock) {
                respLock.wait();
            }
            System.out.println("res received");
        } else {
            System.out.println("should bound before send messages");
        }
    }

    public void submitMessage(SubmitMulti submitMulti) throws IOException, InterruptedException {
        if (isBound) {
            System.out.println("send message");
            smscConnection.sendRequest(submitMulti);
            synchronized (respLock) {
                respLock.wait();
            }
            System.out.println("res received");
        } else {
            System.out.println("should bound before send messages");
        }
    }


    public void unbind() throws IOException {
        smscConnection.unbind();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.exit(0);
        }
        smscConnection.closeLink();
    }

    public static void main(String[] args) throws IOException, InterruptedException {

        SampleClient sampleClient = new SampleClient();

        sampleClient.connect(sampleClient);

        sampleClient.sendSubmitSm(sampleClient);

//        sampleClient.sendSubmitMulti();

        System.out.println("unbinding");

        sampleClient.unbind();
    }

    private void sendSubmitSm(SampleClient sampleClient) throws IOException, InterruptedException {
        SubmitSM submitSM = new SubmitSM();
        submitSM.setSource(new Address(5, 0, "94300724"));
        submitSM.setDestination(new Address(2, 1, "93414549"));
        submitSM.setServiceType("1");
//        submitSM.setMessageText("my sample message", UCS2Encoding.getInstance(true));
//        submitSM.setMessage(sampleClient.hexToByte("0605040B8423F0900601AE02066A00850A0378797A00850370706169642F3132332F6162632E776D6C000601"));
//        submitSM.setMessage(sampleClient.hexToByte("0605040b8423f0900601ae02066a00850c03627279616e6164616d732e636f6d000501"));

//        submitSM.setMessage(sampleClient.hexToByte("53ee53ee549a30fb53ee53ee549a94c358f0591a54cd4eae30fb30fb54c7002157238bde82825c0652306765002c5c0f59294f7f7eb77eb7676562a55230002c5e2667656ee16ee17684795d798f30fb30fb4f207ed951684e16754c002c5e0c671b6b635728770b7b808fc576844f60002c5e735b8900265e78798f00200028005e006f005e"),
//                BinaryEncoding.getInstance());
        submitSM.setEsmClass(64);
        submitSM.setDataCoding(245);
//        submitSM.setRegistered(true);
        TLVTable table = new TLVTable();
        table.set(Tag.LANGUAGE_INDICATOR, 0);
        table.set(Tag.MESSAGE_PAYLOAD, sampleClient.hexToByte("0605040b8423f0900601ae02066a00850c03627279616e6164616d732e636f6d000501"));
////        table.set(Tag.SAR_MSG_REF_NUM, 7);
////        table.set(Tag.SAR_TOTAL_SEGMENTS, 2);
////        table.set(Tag.SAR_SEGMENT_SEQNUM, 1);
//
        submitSM.setTLVTable(table);

//        submitSM.setAlphabet(new ASCIIEncoding());

        sampleClient.submitMessage(submitSM);
    }

    public void sendSubmitMulti() {
        SubmitMulti submitMulti = new SubmitMulti();
        submitMulti.addDestination(new Address(2, 1, "94300724"));
        submitMulti.addDestination(new Address(2, 1, "94300724"));
        submitMulti.setSource(new Address(5, 2, "test"));
//        submitMulti.setMessageText("sample message");
        
        TLVTable tlvTable = new TLVTable();
        tlvTable.set(Tag.MESSAGE_PAYLOAD, "sample message".getBytes());
        tlvTable.set(Tag.SOURCE_PORT, null);
        tlvTable.set(Tag.DESTINATION_PORT, null);

        submitMulti.setTLVTable(tlvTable);
        try {
            this.submitMessage(submitMulti);
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }


    }

    private final String HEXINDEX = "0123456789abcdef          ABCDEF";

    public byte[] hexToByte(String s) {
        int l = s.length() / 2;
        byte data[] = new byte[l];
        int j = 0;

        for (int i = 0; i < l; i++) {
            char c = s.charAt(j++);
            int n, b;

            n = HEXINDEX.indexOf(c);
            b = (n & 0xf) << 4;
            c = s.charAt(j++);
            n = HEXINDEX.indexOf(c);
            b += (n & 0xf);
            data[i] = (byte) b;
        }

        return data;
    }

    public String hexStringToUnicode(String s) {
        byte[] b = hexToByte(s);
        ByteArrayInputStream bin = new ByteArrayInputStream(b);
        DataInputStream in = new DataInputStream(bin);

        try {
            return in.readUTF();
        } catch (IOException e) {
            return null;
        }
    }
}
