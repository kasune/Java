/* 
 *   (C) Copyright 2006-2007 hSenid Software International (Pvt) Limited. 
 *   All Rights Reserved. 
 * 
 *   These materials are unpublished, proprietary, confidential source code of 
 *   hSenid Software International (Pvt) Limited and constitute a TRADE SECRET 
 *   of hSenid Software International (Pvt) Limited. 
 * 
 *   hSenid Software International (Pvt) Limited retains all title to and intellectual 
 *   property rights in these materials. 
 *
 */

import ie.omk.smpp.util.BinaryEncoding;
import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import java.io.IOException;

/**
 * $LastChangedDate$
 * $LastChangedBy$
 * $LastChangedRevision$
 */
public class Encoding {

    public static void main(String[] args) throws IOException {
        System.out.println("testing what going \n\ron ".replaceAll("[\n\r]", " "));
    }
}
