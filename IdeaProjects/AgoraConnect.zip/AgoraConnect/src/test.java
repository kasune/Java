/**
 * Created by IntelliJ IDEA.
 * User: kasun
 * Date: Jun 28, 2007
 * Time: 1:33:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class test {
    public static void main(String args[]){
        String a ="abcdefgh";
        System.out.println(a.charAt(3));

    }
}
