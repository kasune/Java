#!/bin/bash
java -classpath .:../lib/agora-connector-sdk.jar SendOnce
