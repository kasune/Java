// MyGUIClient.java
import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;

public class MyGUIClient extends JFrame {
  // Text area for entering server text
  private static JTextArea jtaServer = new JTextArea();

  // Text area for displaying client text
  private static JTextArea jtaClient = new JTextArea();

  private static JTextArea jtaRooms = new JTextArea();

      private PrintWriter output;

	  private static InetAddress HostAddress;

	  private static Socket MainServer;

	  private static Socket BackupServer;

	  private static final int MAIN_PORT= 1234;

	  private static final int BACKUP_PORT= 1235;

	  private static Scanner network_In;

	  private static PrintWriter network_Out;

	  private static boolean Main_Open_Port=false;

	  private static boolean Backup_Open_Port=false;

     private static boolean read_enable=false;

      private static String InWord;
      private static int InCounter=0;
      private static String chatRooms[] = {"asia","australia"};

  public static void main(String[] args) {
    new MyGUIClient();
      getMessage();
  }

  public MyGUIClient() {
    // Place text area on the frame
    getContentPane().setLayout(new GridLayout(3, 1));
    JScrollPane jScrollPane1 = new JScrollPane(jtaServer);
    JScrollPane jScrollPane2 = new JScrollPane(jtaClient);
    JScrollPane jScrollPane3 = new JScrollPane(jtaRooms);

    jScrollPane1.setBorder(new TitledBorder("Server"));
    jScrollPane2.setBorder(new TitledBorder("Client"));
    jScrollPane3.setBorder(new TitledBorder("Rooms"));

    getContentPane().add(jScrollPane2, BorderLayout.CENTER);
    getContentPane().add(jScrollPane1, BorderLayout.CENTER);
    getContentPane().add(jScrollPane3, BorderLayout.CENTER);

    jtaServer.setWrapStyleWord(true);
    jtaServer.setLineWrap(true);
    jtaClient.setWrapStyleWord(true);
    jtaClient.setLineWrap(true);
    jtaServer.setEditable(false);

    setTitle("MyGUIClient");
    setSize(500, 300);
    setResizable(false);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true);
    GetClientHost();
	//CreateClientSocket();
	jtaClient.setText("Type in ('xxxTERMINATExxx'  *~*~*~ To Close Connection *~*~*~):");
    getChatRooms();
    jtaClient.addKeyListener(new KeyAdapter()

    {

		public void keyPressed(KeyEvent e)
		{

			if (e.getKeyCode() == 10)
			{
               try{
               String inputword=jtaClient.getText();
               String array[]=new String[3];
               array=inputword.split(":");
               System.out.println(InCounter);
               String roo1="NULL1",roo2="NULL2";
                   try{
                       roo2=array[1];
                       roo1=array[2];
                   }catch(ArrayIndexOutOfBoundsException aiob){
                   System.out.println("Null again");
                    roo1="NULL1";
                    roo2="NULL2";

                   //jtaClient.setText("Type in ('xxxTERMINATExxx' *****to Close Connection******:");
               }
                   roo1=roo1.trim();
                   roo2=roo2.trim();
                   System.out.println(roo1+" "+roo2);
                   System.out.println("ok");
                if((roo2.equals("JoinR") && (roo1.equals("asia") || roo1.equals("aus")) && InCounter==0) | (InCounter>0)){
                     InCounter++;
                    System.out.println("hmm");
                     //array=null;
                if(Main_Open_Port==false && Backup_Open_Port==false)
				{
                    System.out.println("hmm-non");
                        jtaServer.append("\n *~*~*~ Reconnecting *~*~*~\n");

						CreateClientSocket();



                        if(Main_Open_Port==true ||Backup_Open_Port==true)
						{
								sendMessages();
						}
						jtaClient.setText("Type in ('xxxTERMINATExxx' *~*~*~ To Close Connection *~*~*~):");

				}
				else
				{
					if(Main_Open_Port==false && Backup_Open_Port==true)
					{
                        System.out.println("hmm-back");
                        CreateClientSocketAgain();
						if(Main_Open_Port==true)
						{
							sendMessages();
						}
						else
						{
							sendMessages();
						}
					}
					else
					{
                        System.out.println("hmm-main");
                        sendMessages();
					}
				}
                {}}
            else{
                jtaRooms.append("\n");
                jtaRooms.append("Please Join Chat room to Proceed");
                jtaRooms.append("\n");
                jtaRooms.append("example- JoinR:asia");
                jtaRooms.append("\n");
                jtaClient.setText("Type in ('xxxTERMINATExxx' *****to Close Connection******:");
                //jtaRooms.setText("");

                getChatRooms();
            }}catch(Exception ex){
                   System.out.println("entered values are wrong"+ex.toString());
                   jtaClient.setText("Type in ('xxxTERMINATExxx' *****to Close Connection******:");
               }}

		}});
}

  public static void getChatRooms(){
             jtaRooms.append("-------Rooms-------");
      for(int i=0;i<chatRooms.length;i++){
             jtaRooms.append("\n");
             jtaRooms.append(chatRooms[i]);

      }

  }
  public void GetClientHost()
	{
		try
		{
			HostAddress = InetAddress.getLocalHost();
		}
		catch(UnknownHostException uhEx)
		{
			System.out.println("\n *~*~*~ Host is Uncreachable *~*~*~\n");
			System.exit(1);
		}
	}
  public void CreateClientSocket()
	{
		try
			{
			try
				{
				jtaServer.append("*~*~*~ Try to Connect to Main Server *~*~*~");
				MainServer = new Socket(HostAddress,MAIN_PORT);
				Main_Open_Port=true;
				jtaServer.append("\n *~*~*~ Connection Establish to Main Server *~*~*~\n");
				network_In =new Scanner(MainServer.getInputStream());
				network_Out =new PrintWriter(MainServer.getOutputStream(),true);
				}
				catch(IOException ioEx)
				{
					jtaServer.append("*~*~*~ Main Server Down *~*~*~ \n *~*~*~ Establish Connection To Backup Server *~*~*~");
					BackupServer = new Socket(HostAddress,BACKUP_PORT);
					Backup_Open_Port=true;
					Main_Open_Port=false;
					jtaServer.append("\n*~*~*~ Connection Establish to BackUp Server *~*~*~\n");
					network_In =new Scanner(BackupServer.getInputStream());
					network_Out =new PrintWriter(BackupServer.getOutputStream(),true);
				}
			}
			catch (IOException e)
			{
				jtaServer.append("\n *~*~*~ BackUp Server is Down As Well *~*~*~");
				Main_Open_Port=false;
				Backup_Open_Port=false;
			}
	}
  public void CreateClientSocketAgain()
	{
		try
			{
					MainServer = new Socket(HostAddress,MAIN_PORT);
					Main_Open_Port=true;
					jtaServer.append("\n*~*~*~ Connected To Main Server *~*~*~\n");
					network_In =new Scanner(MainServer.getInputStream());
					network_Out =new PrintWriter(MainServer.getOutputStream(),true);
					BackupServer.close();
					Backup_Open_Port=false;
			}
				catch(IOException ioEx)
				{
					jtaServer.append("\nMain server still down...");
				}

	}

  public void sendMessages()
	{
		String message=" ", room,clstr;
		char s1;
		String[] array1;
		array1 =new String[3];

		try
		{
				clstr = jtaClient.getText();
                InCounter++;
                array1= clstr.split(":");
				message=array1[1];
				message=message.trim();

            //    array2=message.split("-");
             //   InWord=array2[2];

            if (message.equals("JoinR")){
                room=array1[2];
                InWord=room;
                //message=message.concat(":");
                message=message.concat(room);
                System.out.println("sender- "+message);

                network_Out.println(message);

                array1=null;
            }else{
                InWord = InWord.trim();
               String tmp1 = InWord.concat(":");
               String tmp2 = tmp1.concat(message);
                message = tmp2;
               System.out.println("sender- "+message);

                network_Out.println(message);
                tmp1=null;
                tmp2=null;
                array1=null;
            }
    /*			if(network_In.hasNext())
				{
					response = network_In.nextLine();
                    jtaServer.append( "Response From "+response);
					jtaServer.append("\n");      */
					jtaClient.setText("Type in ('xxxTERMINATExxx' *****to Close Connection******:");

		/*			if(response.equals("Backup Server>xxxTERMINATExxx"))
					{
						BackupServer.close();
						Backup_Open_Port=false;
						jtaClient.setText("\nClosing connection for Backup Server.....");
						jtaClient.setEditable(false);
						}
						else
						{
							if(response.equals("Main Server>xxxTERMINATExxx"))
							{
								MainServer.close();
								Main_Open_Port=false;
								jtaClient.setText("\nClosing connection for Main Server.....");
								jtaClient.setEditable(false);
							}
						}
				}
					else
					{
						jtaServer.append("*~*~*~Reconnecting*~*~*~");
						CreateClientSocket();
						if(Main_Open_Port==true ||Backup_Open_Port==true)
						{
							sendMessages();
						}
						jtaClient.setText("Type in ('xxxTERMINATExxx' *~*~*~ to Close Connection *~*~*~ :");

					}  */
			}
			catch(Exception ioEx)
			{
				jtaServer.append("*~*~*~Unable to Disconnect*~*~*~");
				System.exit(1);
			}

		}
    public static void getMessage(){
        //ReceiveHandler rh= new ReceiveHandler(network_In, network_Out, jtaServer );
        //rh.start();
        System.out.println("receiver started");

        while(true){
            try{
                 //jserver.append("hmmmm--sss");
                 String response = network_In.nextLine();
					jtaServer.append( "Response From "+response);
					jtaServer.append("\n");
                    System.out.println("response"+response);
                //}

            Thread.sleep(1000);

            }catch(InterruptedException ie){
                System.out.println(ie.toString());
               }
            catch(NullPointerException npe){
                //System.out.println(npe.toString());
            }

        }
    }
}
    class ReceiveHandler extends Thread{
         Scanner net_in;
         PrintWriter net_out;
         JTextArea jserver;
        ReceiveHandler(Scanner in, PrintWriter out, JTextArea js){
          net_in=in;
          net_out=out;
          jserver=js;
        }

        public void run(){
            while(true){
            try{
                 //jserver.append("hmmmm--sss");
                 String response = net_in.nextLine();
					//jserver.append( "Response From "+response);
					//jserver.append("\n");
                    System.out.println("response"+response);
                //}

            Thread.sleep(10000);

            }catch(InterruptedException ie){
                System.out.println(ie.toString());
               }
            catch(NullPointerException npe){
                //System.out.println(npe.toString());
            }
        }}
    }
